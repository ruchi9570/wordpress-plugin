<?php
function rrmdir($dir) {
  if (is_dir($dir)) {
    $objects = scandir($dir);
    foreach ($objects as $object) {
      if ($object != "." && $object != "..") {
        if (filetype($dir."/".$object) == "dir") 
           rrmdir($dir."/".$object); 
        else unlink   ($dir."/".$object);
      }
    }
    reset($objects);
    rmdir($dir);
  }
 }
add_action('wp_ajax_make_download', 'make_download');
add_action('wp_ajax_nopriv_make_download', 'make_download');
function make_download(){
	//print_r($_POST);
	 
	ini_set('max_execution_time', '0'); // for infinite time of execution 
	$temp = plugin_dir_path( __FILE__ ).'temp/';
	rrmdir($temp);
	if (!file_exists($temp)) {		
		mkdir($temp, 0777, true);		
	} 
	$post_name = get_the_title($_POST["postid"]);
	$image_folder_name = $_POST['images_folder_name'];    
	$html_file_name = $_POST['html_file_name'];    
	$css_file_name = $_POST['css_file_name'];    
	$clean_js_code = $_POST['clean_js_code'];    
	$disable_url = $_POST['disable_url'];    
	$clean_links = $_POST['clean_links'];   
	$clean_srcset_code = $_POST['clean_srcset_code'];
	$clean_domain = $_POST['clean_domain'];   
	$src = true;
	$js = true;
	$cssname = !empty( $css_file_name ) ? $css_file_name : 'style';
	$jscript = 'js';
	$htmlname = !empty( $html_file_name ) ? $html_file_name : 'index';
	$image = !empty( $image_folder_name ) ? $image_folder_name : 'images';
	if (!file_exists($temp.$image)) {		
		mkdir($temp.$image, 0777, true);		
	}	 
	$url = $_POST['url'];
	//$url = 'http://localhost/testing-wp/wp-content/plugins/export-page-plugin/test.html';
	//$url = 'https://www.matinnews.co/ceux-qui-nont-pas-la-clim-se-ruent-sur-cet-oreiller-rafraichissant-tres-efficace/';
	//$url = 'https://berlin.wpestatetheme.org/properties/stunning-villa-to-rent/';
	 
	$html = file_get_contents($url); 

	$html2 = $html; 
	$html2 = preg_replace('/<a(.*)href="(.*?)"(.*)>/','<a notremove="1"$1href="$2"$3>', $html2);
	$html2 = preg_replace('/<script(.*?)>/','<script notremove="1"$1>', $html2);
	//$html2 = preg_replace('/><script(.*?)>/','><script notremove="1"$1>', $html2);
	//$html2 = preg_replace('/<div(.*)class="(.*)mh-copyright-wrap(.*)">(.*)>/','><script notremove="1"$1>', $html2);
//die($html2);
//'/<div id="main-content"(.*?)>[\s\S]*?<article\b[^>]*>[\s\S]*?(<\/article>)[\s\S]*?(<\/div>)/is',
	$html2 = preg_replace_callback(
        '/<article id="page-(.*?)"(.*?)>[\s\S]*?(<\/article>)/is',
        function ($matches) {
		   // print_r($matches);
           // return str_replace('script', 'script22',$matches[0]);
            $matches[0] = preg_replace('/<a(.*?)notremove="1"(.*)>/','<a$1notremove="0"$2>', $matches[0]);
            $matches[0] = preg_replace('/<script(.*?)notremove="1"(.*)>/','<script$1notremove="0"$2>', $matches[0]);
            return preg_replace('/<script(.*?)notremove="1"(.*)>/','<script$1notremove="0"$2>', $matches[0]);
        },
        $html2
     );
	  // die($html2);
	 $html2 = preg_replace_callback(
        '/<img(.*)src="(.*?)"(.*)>/',
        function ($matches) {
			//print_r($matches);
			$image = isset( $_POST['images_folder_name'] ) ? $_POST['images_folder_name'] : 'images';
		    $path_info = pathinfo($matches[2]);
			$ext = isset($path_info['extension']) ? '' : '.png';
			$fullname = $image.'/'.(strtok(basename($matches[2]), "?").$ext);
            return preg_replace('/<img(.*)src="(.*?)"(.*)>/','<img$1src="'.$fullname.'"$3>',$matches[0]);
        },
        $html2
     );
	 $html2 = preg_replace_callback(
        '/<img(.*)src=\'(.*?)\'(.*)>/',
        function ($matches) {
			//print_r($matches);
			$image = isset( $_POST['images_folder_name'] ) ? $_POST['images_folder_name'] : 'images';
		    $path_info = pathinfo($matches[2]);
			$ext = isset($path_info['extension']) ? '' : '.png';
			$fullname = $image.'/'.(strtok(basename($matches[2]), "?").$ext);
            return preg_replace('/<img(.*)src=\'(.*?)\'(.*)>/','<img$1src="'.$fullname.'"$3>',$matches[0]);
        },
        $html2
     );
	// die( $html2); 
	
	$doc = new DOMDocument();
	$internalErrors = libxml_use_internal_errors(true);
	$doc->loadHTML($html);
	libxml_use_internal_errors($internalErrors);
	//die();
//images parse
	$images = $doc->getElementsByTagName('img');
	foreach($images as $img){
		$src = $img->getAttribute('src');
		$path_info = pathinfo($src);
		$ext = isset($path_info['extension']) ? '' : '.png';
		if($src){
			file_put_contents($temp.$image.'/'.(strtok(basename($src), "?").$ext), file_get_contents($src));
		}
	}//die();
//css parse	
	$csscode = '';
	$links = $doc->getElementsByTagName('link');
	foreach($links as $link){
		$css = $link->getAttribute('href');
		$parse_url = parse_url($css);		
		$output = explode("/",$parse_url["path"]);
		$max = max(array_keys($output));		
		$path_info = pathinfo($output[$max]);
        $extension = $path_info['extension']; 
		if($extension == 'css'){
			$csscode.= file_get_contents($css);
		}
	}
 	file_put_contents($temp.$cssname.'.css', $csscode);
 //js parse	
	$jshead = '';
 if($clean_js_code){
	$scripts = $doc->getElementsByTagName('script');
	foreach($scripts as $script){
		$jsss = $script->getAttribute('src');
		if($jsss != '' && !$clean_js_code){
			file_put_contents($temp.(strtok(basename($jsss), "?")), file_get_contents($jsss));
			$jshead.= '<script type="text/javascript" src="'.basename($jsss).'"></script>';
		}
	} 
 }

//store to folder
	//$doc->save($temp.$htmlname.".html");	
	   
	if($disable_url){
		$html2 = preg_replace('/<form(.*)action="(.*?)"(.*)>/','<form$1action="#"$3>',$html2); //form
		$html2 = preg_replace('/<form(.*)action=\'(.*?)\'(.*)>/','<form$1action="#"$3>',$html2); //form
	}
	if($clean_srcset_code){
		$html2 = preg_replace('/<img(.*)srcset="(.*?)"(.*)>/','<img$1$3>',$html2); // img 
		$html2 = preg_replace('/<img(.*)srcset=\'(.*?)\'(.*)>/','<img$1$3>',$html2); // img 
	} //- srcset
	if($clean_links){
		$html2 = preg_replace('/<a(.*)href="(.*?)"(.*)>/','<a$1href="#"$3>',$html2); // a
		$html2 = preg_replace('/<a(.*)href=\'(.*?)\'(.*)>/','<a$1href="#"$3>',$html2); // a
	}
	if($clean_js_code){
	$html2 = preg_replace('/<script(.*?)notremove="1"(.*?)>[\s\S]*?(<\/script>)/', "", $html2);
	//$html2 = preg_replace('/(<(script)\b[^>]*>).*?(<\/\2>)/is', "", $html2); // script
	 
	}
	if($clean_domain)
	$html2 = preg_replace('/(<(head)\b[^>]*>).*?(<\/\2>)/is', "<head><meta http-equiv='Content-Type' content='text/html; charset=utf-8' /><link rel='stylesheet' href='".$css_file_name.".css' type='text/css' media='all' />$jshead</head>", $html2);
	//$html2 = preg_replace('/(<(body)\b[^>]*>).*?(<\/\2>)/is', $jshead, $html2);
	//$html2 = preg_replace('#<body(.*?)</body>#is', '<body$1'.$jshead.'</body>', $html2);
	//die($html2 );
	file_put_contents($temp.$htmlname.".html", $html2);
	//echo $html = file_get_contents($temp.$htmlname.".html");
	die();
}

function myinit(){   
	if(isset($_GET['adtdownload'])){
		error_reporting(0);
		// Get real path for our folder
		$rootPath = realpath(plugin_dir_path( __FILE__ ).'temp');
		$zipname = 'file.zip';
		// Initialize archive object
		$zip = new ZipArchive();
		$zip->open($zipname, ZipArchive::CREATE | ZipArchive::OVERWRITE);

		// Create recursive directory iterator
		/** @var SplFileInfo[] $files */
		$files = new RecursiveIteratorIterator(
			new RecursiveDirectoryIterator($rootPath),
			RecursiveIteratorIterator::LEAVES_ONLY
		);

		foreach ($files as $name => $file)
		{
			// Skip directories (they would be added automatically)
			if (!$file->isDir())
			{
				// Get real and relative path for current file
				$filePath = $file->getRealPath();
				$relativePath = substr($filePath, strlen($rootPath) + 1);

				// Add current file to archive
				$zip->addFile($filePath, $relativePath);
			}
		}

		// Zip archive will be created only after closing object
		$zip->close();	
		header('Content-Type: application/zip');
		header('Content-disposition: attachment; filename='.$zipname);
		header('Content-Length: ' . filesize($zipname));
		readfile($zipname);	
die();		
	}
}
add_action('init','myinit');
?>